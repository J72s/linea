const strings = require("../strings.json");
const utils = require("../utils");
const allowedUsers = require("../allowed.json").allowed;

/** 
 * @description Change the bot's display name in a guild
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    try {
        // Check if the message is sent in a guild
        if (!message.guild) {
            return message.channel.send(strings.notInGuild2);
        }

        // Check if the message author is allowed to manage nicknames
        if (!allowedUsers === message.author.id) {
            return;
        }

        // Join the arguments to form the new display name
        const newNickname = args.join(" ");

        // Check if the new display name is provided
        if (!newNickname) {
            return message.channel.send(strings.noNickname);
        }

        // Set the bot's display name to the provided one
        await message.guild.me.setNickname(newNickname);

        // Send a confirmation message
        message.channel.send(strings.nicknameChanged);
    } catch (error) {
        // Log the error
        console.error("Error occurred while changing nickname:", error);
        
        // Send the error to the specified text channel
        const errorChannelId = '1240780333826445372'; // Replace with your error channel ID
        const errorChannel = client.channels.cache.get(errorChannelId);
        if (errorChannel && errorChannel.type === 'text') {
            errorChannel.send("Error occurred while changing nickname:", error);
        } else {
            console.error("Error channel not found or not a text channel.");
        }

        message.channel.send(strings.errorChangingNickname);
    }
};

module.exports.names = {
    list: ["changenickname", "name", "تغييرالاسم"]
};
