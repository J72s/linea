module.exports = {
    names: {
      list: ['ping']
    },
    run: async (client, message, args) => {
      message.channel.send('Pong!');
    }
  };
  