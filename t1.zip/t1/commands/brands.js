const fs = require('fs');
const path = require('path');
const strings = require("../strings.json");
const utils = require("../utils");
const allowedUsers = require("../allowed.json").allowed;
const brandsData = require("../brands.json");

/**
 * @description ابدأ لعبة حيث يجب على المستخدمين تخمين اسم العلامة التجارية من الصورة المعطاة
 * @param {Discord.Client} client العميل الذي يشغل الأوامر
 * @param {Discord.Message} message رسالة الأمر
 * @param {Array<String>} args الحجج الممررة مع الأمر
 */
module.exports.run = async (client, message, args) => {
    try {
        let roundCount = parseInt(args[0], 10); // عدد الجولات المحددة من قبل المستخدم
        if (isNaN(roundCount) || roundCount <= 0) {
            message.channel.send("يرجى تحديد عدد صحيح من الجولات.");
            return;
        }

        let currentRoundIndex = 0;
        let scores = {};

        message.channel.send(strings.eventStart4);

        const askQuestion = async () => {
            if (currentRoundIndex >= roundCount) {
                // نهاية اللعبة، إعلان الفائز
                let scoreMessage = "**انتهت اللعبة! إليكم النقاط النهائية:**\n";
                const sortedScores = Object.entries(scores).sort((a, b) => b[1] - a[1]);

                sortedScores.forEach(([user, points]) => {
                    scoreMessage += `${user}: ${points} نقاط\n`;
                });

                if (sortedScores.length === 0) {
                    scoreMessage += "لم يجيب أحد بشكل صحيح.";
                }

                message.channel.send(scoreMessage);
                return;
            }

            const randomBrand = brandsData[Math.floor(Math.random() * brandsData.length)];
            const questionMessage = await message.channel.send({
                content: strings.questionPrompt4.replace("{brand}", randomBrand.name),
                files: [randomBrand.image]
            });

            const filter = response => {
                const brandName = response.content.trim();
                return brandName.toLowerCase() === randomBrand.name.toLowerCase();
            };

            const collector = message.channel.createMessageCollector({ filter, time: 30000 });

            collector.on('collect', (response) => {
                const user = response.author.tag;
                if (!scores[user]) scores[user] = 0;

                scores[user] += 1; // كل إجابة صحيحة تحصل على نقطة واحدة

                response.channel.send(strings.correctAnswer.replace("{user}", response.author).replace("{points}", 1));
                collector.stop('answered');
            });

            collector.on('end', (collected, reason) => {
                if (reason === 'time') {
                    message.channel.send(strings.timeUp);
                }

                currentRoundIndex++;
                if (currentRoundIndex < roundCount) {
                    askQuestion();
                } else {
                    // نهاية اللعبة
                    let scoreMessage = "**انتهت اللعبة! إليكم النقاط النهائية:**\n";
                    const sortedScores = Object.entries(scores).sort((a, b) => b[1] - a[1]);

                    sortedScores.forEach(([user, points]) => {
                        scoreMessage += `${user}: ${points} نقاط\n`;
                    });

                    if (sortedScores.length === 0) {
                        scoreMessage += "لم يجيب أحد بشكل صحيح.";
                    }

                    message.channel.send(scoreMessage);
                }
            });
        };

        askQuestion();

    } catch (error) {
        // سجل الخطأ
        console.error("حدث خطأ أثناء اللعبة:", error);
        message.channel.send(strings.errorStartingGame);
    }
};

module.exports.names = {
    list: ["براند", "brands"]
};
