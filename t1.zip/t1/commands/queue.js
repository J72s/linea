const strings = require("../strings.json");
const utils = require("../utils");
const allowedUsers = require("../allowed.json").allowed;

/** 
 * @description Show the guild's song queue
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args command arguments
 */
module.exports.run = async (client, message, args) => {
    try {
        const serverQueue = queue.get("queue");

        if (!serverQueue || !serverQueue.songs) {
            return message.channel.send(strings.noSongsQueued);
        }

        let queuetxt = "";

        for (let i = 0; i < serverQueue.songs.length; i++) {
            const song = serverQueue.songs[i];
            const minutes = Math.floor(song.duration / 60);
            const seconds = song.duration % 60;

            const formattedTime = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

            const queueTextEntry = `${i + 1}. (${formattedTime}) ${song.title} requested by ${song.requestedby}`;
            queuetxt += `\`\`${queueTextEntry}\`\`\n`;
        }

        if (args[0] === "seek") {
            // Check if a song is playing
            if (!serverQueue.dispatcher) {
                return message.channel.send("There's no song playing to seek.");
            }

            // Check if the song is at least 10 seconds in
            if (serverQueue.dispatcher.streamTime < 10000) {
                return message.channel.send("The song is not at least 10 seconds in to seek.");
            }

            // Seek forward by 10 seconds
            serverQueue.dispatcher.end();
            return message.channel.send("Seeked forward by 10 seconds.");
        }

        client.channels.cache.get('1240050863007862815').send("Showed music queue");
        return message.channel.send(strings.musicsQueued + "\n" + queuetxt);
    } catch (error) {
        // Log the error
        console.error("Error occurred while showing music queue:", error);
        
        // Send the error to the specified text channel
        const errorChannelId = '1240780333826445372'; // Replace with your error channel ID
        const errorChannel = client.channels.cache.get(errorChannelId);
        if (errorChannel && errorChannel.type === 'text') {
            errorChannel.send("Error occurred while showing music queue:", error);
        } else {
            console.error("Error channel not found or not a text channel.");
        }

        message.channel.send(strings.errorMusicQueue);
    }
};

module.exports.names = {
    list: ["queue", "q"]
};
