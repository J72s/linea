const fs = require('fs');
const { Client, Intents } = require('discord.js');
const { joinVoiceChannel, getVoiceConnection } = require('@discordjs/voice');
const allowedUsers = require("../allowed.json").allowed;

const vcConfigPath = '../vcConfig.json';

/**
 * @description Joins multiple voice channels in sequence based on provided IDs and time interval, and alternates mute/unmute state
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    try {
        if (!allowedUsers.includes(message.author.id)) {
            message.channel.send("You don't have permission to use this command.");
            return;
        }

        if (args[0] === 'stop') {
            clearInterval(vcInterval);
            message.channel.send("Stopped switching voice channels.");
            return;
        }

        if (args[0] === 'randomvc' && args.length >= 2) {
            const vcIds = args.slice(1);

            if (vcIds.some(id => !client.channels.cache.get(id) || client.channels.cache.get(id).type !== 'GUILD_VOICE')) {
                message.channel.send("Please provide valid voice channel IDs.");
                return;
            }

            const vcConfig = { vcIds };
            fs.writeFileSync(vcConfigPath, JSON.stringify(vcConfig));
            message.channel.send("Voice channel IDs saved. Switching will begin shortly.");

            startSwitchingVC(client, message, 30); // Set interval to 30 minutes
        } else {
            message.channel.send("Please provide the command 'randomvc' followed by multiple voice channel IDs.");
        }
    } catch (error) {
        console.error("Error occurred during the event:", error);
        message.channel.send("An error occurred while processing the command.");
    }
};

let vcInterval;

async function startSwitchingVC(client, message, interval) {
    try {
        const { vcIds } = JSON.parse(fs.readFileSync(vcConfigPath));
        let currentIndex = 0;
        let muted = false;

        const switchVC = async () => {
            const channel = client.channels.cache.get(vcIds[currentIndex]);
            if (!channel) {
                console.log(`Invalid channel: ${vcIds[currentIndex]}`);
                return;
            }

            const connection = joinVoiceChannel({
                channelId: channel.id,
                guildId: channel.guild.id,
                adapterCreator: channel.guild.voiceAdapterCreator,
            });

            // Toggle mute state
            if (muted) {
                await connection.receiver.connection.setSpeaking(false);
                muted = false;
                console.log(`Unmuted in channel: ${channel.name}`);
            } else {
                await connection.receiver.connection.setSpeaking(true);
                muted = true;
                console.log(`Muted in channel: ${channel.name}`);
            }

            message.channel.send(`Joined voice channel: ${channel.name} and ${muted ? 'muted' : 'unmuted'}`);

            currentIndex = (currentIndex + 1) % vcIds.length;
        };

        switchVC();
        vcInterval = setInterval(switchVC, interval * 60000); // Convert minutes to milliseconds
    } catch (error) {
        console.error("Error occurred during voice channel switching:", error);
        message.channel.send("An error occurred while switching voice channels.");
    }
}

module.exports.names = {
    list: ["randomvc", "stop"]
};
